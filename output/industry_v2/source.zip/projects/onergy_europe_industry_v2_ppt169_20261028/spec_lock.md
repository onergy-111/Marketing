# Execution Lock
## canvas
- viewBox: 0 0 1280 720
- format: PPT 16:9
## colors
- bg: #FFFFFF
- secondary_bg: #F3F6F8
- text: #142C3A
- primary: #F58A24
- primary_text: #B94B00
- accent: #087CC1
- text_secondary: #627582
- border: #D7E1E7
- pale_blue: #EAF3F9
## typography
- font_family: "Noto Sans CJK SC", "Microsoft YaHei", sans-serif
- title: 32
- body: 22
- subtitle: 26
- annotation: 13
- cover_title: 52
- hero_number: 64
## icons
- library: none
- inventory: none
## images
- images/bulgaria-site.jpeg | user | Existing | no-crop
- images/china-site.jpeg | user | Existing | no-crop
- images/hub-exterior.jpeg | user | Existing | no-crop
- images/hub-workshop.jpeg | user | Existing | no-crop
- images/hungary-pcs.jpeg | user | Existing | no-crop
- images/hungary-site.jpeg | user | Existing | no-crop
- images/logo.png | user | Existing | no-crop
- images/netherlands-site.jpeg | user | Existing | no-crop
- images/pcs-repair.jpeg | user | Existing | no-crop
- images/poland-site.jpeg | user | Existing | no-crop
## page_rhythm
- P01: anchor
- P02: dense
- P03: dense
- P04: dense
- P05: dense
- P06: dense
- P07: dense
- P08: dense
- P09: dense
- P10: dense
- P11: dense
- P12: dense
- P13: dense
- P14: dense
- P15: dense
- P16: dense
- P17: dense
- P18: dense
- P19: dense
- P20: dense
- P21: dense
- P22: anchor
## branding
- upper_right: Company logo, x1104 y24 width112 height43
- lower_left: 历橙 你的能源历程伙伴, x64 y686
## forbidden
- Unverified industry statistics or legal claims
- Company sales pitch in pages 1 through 18
- Paid APIs
