# onergy_europe_om

- Canvas format: ppt169
- Created: 20261027

## Directories

- `svg_output/`: raw SVG output
- `svg_final/`: finalized SVG output
- `images/`: presentation assets
- `notes/`: speaker notes
- `templates/`: project templates
- `sources/`: source materials and normalized markdown
- `exports/`: main native pptx (timestamped); `_svg.pptx` sibling added when exported with `--svg-snapshot`
- `backup/<timestamp>/`: svg_output/ archive (always written in default-flow mode; safe to delete old timestamps)
