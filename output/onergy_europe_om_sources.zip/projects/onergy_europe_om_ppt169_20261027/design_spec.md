# ONERGY Europe O&M — Design Spec
## I. Project Information
- Project Name: onergy_europe_om
- Canvas Format: PPT 16:9, 1280×720
- Page Count: 20
- Design Style: General Consulting + editorial industrial minimalism
- Target Audience: 海外储能设备厂商运维负责人
- Use Case: 欧洲储能运维主题演讲；中文初稿
- Created Date: 2026-10-27
- Authorization: 用户已指定受众、主题、约20页、16:9中文、原稿品牌和直接完成初稿；以此执行设计默认选择，不追加审批。
## II. Canvas Specification
- Format: ppt169
- Dimensions: 1280×720
- viewBox: 0 0 1280 720
- Margins: 64左右；标题顶88；页脚680；正文区域170—620
## III. Visual Theme
- 白底为主，少量深蓝观点页；橙色点题、蓝色表示服务和证据。
- Background #FFFFFF; secondary #F3F6F8; dark/text #142C3A; primary #F58A24; accessible orange text #B94B00; accent #087CC1; secondary text #627582; border #D7E1E7; pale blue #EAF3F9.
- Reference: sources/slide-references/reference_analysis.md。保留原稿橙蓝与真实照片；重新组织信息密度与层级。
## IV. Typography System
- Confirmed override: Noto Sans CJK SC（本机已安装，接收端需安装；不嵌入字体）。
- All roles: 'Noto Sans CJK SC', 'Microsoft YaHei', sans-serif
- Body 22px; title 34px; subtitle 26px; footnote 13px; cover 54px; hero 72px.
- 无复杂公式，无公式渲染或外部API。
## V. Layout Principles
- 观点标题，一页一个判断；矩阵、开放式分栏、案例照片、时间组成分析交替。
- 内容框以直线分隔，不堆叠圆角卡片；不使用生硬流程图。
- 图片保留真实比例，可按已知源图裁切；文字及结构尽量原生可编辑。
- 数据缺失明确标“待补充”；建议方案标示；不使用无法核验的行业数字/法规。
## VI. Icon Usage Specification
- 无外部图标；仅手工简单几何与原稿logo，不混用图标库。
## VII. Visualization Reference List
- P04 停机时间概念组成；不编码比例；无数值坐标。
- P05 指标定义表和待补充基线；P08 服务时效梯度列表，非统计图。
- 不使用图表模板、不绘制虚构数据；因此page_charts省略。
## VIII. Image Resource List
| File | Acquire Via | Status | Intent | Source |
|---|---|---|---|---|
| images/logo.png | user | Existing | documentary / accent | PDF p1 |
| images/hub-exterior.jpeg | user | Existing | documentary / accent | PDF p20 |
| images/hub-workshop.jpeg | user | Existing | documentary / accent | PDF p19 |
| images/hungary-site.jpeg | user | Existing | documentary / accent | PDF p30 |
| images/hungary-pcs.jpeg | user | Existing | documentary / accent | PDF p30 |
| images/bulgaria-site.jpeg | user | Existing | documentary / accent | PDF p29 |
| images/poland-site.jpeg | user | Existing | documentary / accent | PDF p29 |
| images/netherlands-site.jpeg | user | Existing | documentary / accent | PDF p29 |
| images/pcs-repair.jpeg | user | Existing | documentary / accent | PDF p31 |
| images/china-site.jpeg | user | Existing | documentary / accent | PDF p27 |
## IX. Content Outline

### P01 — 欧洲储能运维，真正交付的是可用性
- Page role: cover
- page_rhythm: anchor
- Key message: 以可用性、响应效率和长期运营表现为主线，讨论设备厂商在欧洲的服务履约。
- Reference source: company.pdf / 专业分析
- Reference page: —
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P02 — 从“按期并网”到“持续履约”，服务重心正在后移
- Page role: content
- page_rhythm: dense
- Key message: 项目交付不是售后终点。调试遗留、运行工况变化和质保期服务都需要可持续的本地执行；本页为业务判断，无行业装机统计。
- Reference source: company.pdf / 专业分析
- Reference page: 综合判断；公司PDF第15—17页服务语境
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P03 — 最难的不是识别告警，而是把问题推进到现场闭环
- Page role: content
- page_rhythm: dense
- Key message: 关键摩擦是远程诊断与现场验证脱节、人员与准入不匹配、备件物流等待、恢复后的证据不完整。
- Reference source: company.pdf / 专业分析
- Reference page: 公司PDF第13、16、17、19页；建议分析
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P04 — 缩短停机，先缩短那些没有技术动作的等待
- Page role: content
- page_rhythm: breathing
- Key message: 总恢复时间包含确认、资源到位、技术处置、验证交接；图形是概念拆解，不表示真实耗时比例。
- Reference source: company.pdf / 专业分析
- Reference page: 建议分析，非实测模型
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P05 — 先统一指标口径，才谈得清运维价值
- Page role: content
- page_rhythm: dense
- Key message: 建议共同定义技术可用率、首次响应、现场到达、恢复时长和重复故障；所有实际值留待补充。
- Reference source: company.pdf / 专业分析
- Reference page: 建议指标口径，实际数据待补充
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P06 — 历橙的角色：把储能经验转化为本地执行能力
- Page role: content
- page_rhythm: dense
- Key message: 苏州市历橙新能源有限公司成立于2024年，聚焦能源后市场；原稿2012年以来经历属于团队履历，不等于公司成立时间。
- Reference source: company.pdf / 专业分析
- Reference page: 公司PDF第1、9、10页
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P07 — 布达佩斯枢纽，让工程师、备件与维修更贴近项目
- Page role: content
- page_rhythm: dense
- Key message: 原稿称欧洲运营中心位于布达佩斯、仓储维修区约8000平方米，并列明吊装转运和仓储服务；具体库存/资质以合同核验。
- Reference source: company.pdf / 专业分析
- Reference page: 公司PDF第14、19、20页
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P08 — 欧洲响应应分层承诺，而不是承诺“全域同速”
- Page role: content
- page_rhythm: dense
- Key message: 原稿服务时效按区域梯度列示，并不自动构成SLA。跨国资格、客户准入、备件与通行需单独确认，英国单独安排。
- Reference source: company.pdf / 专业分析
- Reference page: 公司PDF第13页
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P09 — 面向设备厂商，服务能力要围绕交付结果组织
- Page role: content
- page_rhythm: dense
- Key message: 组织为投运支持、运行保障、故障恢复、维修检测四种结果；技术方案和参数变更保留厂商审批权。
- Reference source: company.pdf / 专业分析
- Reference page: 公司PDF第15—17、21页
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P10 — 现场服务的终点，是有证据的恢复与交接
- Page role: content
- page_rhythm: dense
- Key message: 冷/热调试、保护与通信验证、系统测试到交接均需记录；不把操作步骤写成培训教程。
- Reference source: company.pdf / 专业分析
- Reference page: 公司PDF第16、17页
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P11 — 远程支持的价值，是让第一次到场更有准备
- Page role: content
- page_rhythm: dense
- Key message: 远程输出工作假设、排查边界、备件工具和成功验证条件；真实的首访修复率仍待补充。
- Reference source: company.pdf / 专业分析
- Reference page: 公司PDF第15、17、22页；建议分析
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P12 — 预防性维护，应优先处理影响可用性的风险
- Page role: content
- page_rhythm: dense
- Key message: 按安全与可用性影响、复发性和可检测性安排维护优先级；计划停机与非计划故障分开统计。
- Reference source: company.pdf / 专业分析
- Reference page: 公司PDF第17页；建议分析
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P13 — 备件与维修能力，决定故障恢复能否真正闭环
- Page role: content
- page_rhythm: dense
- Key message: 原稿提供300+ PCS模块维修记录，覆盖检测、更换、测试及返修验证；统计期间与合格率待补充。
- Reference source: company.pdf / 专业分析
- Reference page: 公司PDF第19、21、31页
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P14 — 国内经验提供工程纵深，欧洲交付遵循当地条件
- Page role: content
- page_rhythm: dense
- Key message: 公司材料称2025.06—2026.06储能项目实证1000+、覆盖18省；不等同于独立电站数量，不外推欧洲交付指标。
- Reference source: company.pdf / 专业分析
- Reference page: 公司PDF第27页
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P15 — 匈牙利 100 MWh：把调试、验证与并网准备连起来
- Page role: content
- page_rhythm: dense
- Key message: 原稿第30页：匈牙利100MWh光伏配储，变压器系统诊断调试、PCS校验通电、安规及功能验证；实际完成日期和量化改善待补充。
- Reference source: company.pdf / 专业分析
- Reference page: 公司PDF第30页
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P16 — 三个欧洲项目，体现不同故障场景下的执行能力
- Page role: content
- page_rhythm: dense
- Key message: 原稿第29页：保加利亚100MWh液冷系统维护；波兰115MWh设备维护/柜体钣金修复；荷兰工商业PCS诊断、更换和调试。20+场站与波兰单项目的统计关系待确认。
- Reference source: company.pdf / 专业分析
- Reference page: 公司PDF第29页
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P17 — 让小程序成为“服务证据入口”，而非又一个看板
- Page role: content
- page_rhythm: dense
- Key message: 原稿支持工单和报告类交付，但未提供小程序上线证据；本页为建议方案，串联接单、现场记录、授权确认、验收及复盘。
- Reference source: company.pdf / 专业分析
- Reference page: 公司PDF第17、24页；建议方案
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P18 — AI 的价值：更早识别、更快定位、更少重复劳动
- Page role: content
- page_rhythm: breathing
- Key message: 原稿有诊断、状态评估和决策支持方向，没有AI项目实测结果。本页为建议方案，AI仅辅助人类判断，不自动控制设备或替代安全审批。
- Reference source: company.pdf / 专业分析
- Reference page: 公司PDF第23、24页；建议方案
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P19 — 合作从清晰的服务边界与可验收试点开始
- Page role: content
- page_rhythm: dense
- Key message: 可按单项目专项、区域现场支持、持续运维三种范围合作；先确认站点条件、责任、验收证据与指标，再以试点检验。
- Reference source: company.pdf / 专业分析
- Reference page: 建议合作范围，非现有合同承诺
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

### P20 — 让每一次现场行动，都回到长期可用性
- Page role: ending
- page_rhythm: anchor
- Key message: 围绕目标国家与设备、关键失效场景、服务指标及现有基线，共同确认一个可衡量的欧洲服务试点。
- Reference source: company.pdf / 专业分析
- Reference page: 建议合作讨论
- Preserve: 品牌橙蓝、来源事实与相关项目照片
- Adapt: 观点标题及开放式分栏，避免照搬原稿细碎文本

## X. Speaker Notes Requirements
- 逐页中文讲稿，补充口径与证据边界，不虚构现场成果；源页码写入说明。
## XI. Technical Constraints Reminder
- SVG仅原生文字、形状、线和图片；禁用脚本/CSS/foreignObject。
- SVG逐页手工编写；每页读取spec_lock；不使用批量SVG生成器。
- 运行质量检查、讲稿拆分、后处理、原生导出；本任务无收费API、无Git提交。
- 使用已准备的最小环境，不运行bootstrap安装全部可选依赖。
