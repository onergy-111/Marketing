# Execution Lock
## canvas
- viewBox: 0 0 1280 720
- format: PPT 16:9
## colors
- bg: #FFFFFF
- secondary_bg: #F3F6F8
- text: #142C3A
- primary: #F58A24
- primary_text: #B94B00
- accent: #087CC1
- text_secondary: #627582
- border: #D7E1E7
- pale_blue: #EAF3F9
## typography
- font_family: "Noto Sans CJK SC", "Microsoft YaHei", sans-serif
- body: 22
- title: 34
- subtitle: 26
- annotation: 13
- cover_title: 54
- hero_number: 72
## icons
- library: none
- inventory: none
## images
- images/logo.png | user | Existing | no-crop
- images/hub-exterior.jpeg | user | Existing | no-crop
- images/hub-workshop.jpeg | user | Existing | no-crop
- images/hungary-site.jpeg | user | Existing | no-crop
- images/hungary-pcs.jpeg | user | Existing | no-crop
- images/bulgaria-site.jpeg | user | Existing | no-crop
- images/poland-site.jpeg | user | Existing | no-crop
- images/netherlands-site.jpeg | user | Existing | no-crop
- images/pcs-repair.jpeg | user | Existing | no-crop
- images/china-site.jpeg | user | Existing | no-crop
## page_rhythm
- P01: anchor
- P02: dense
- P03: dense
- P04: breathing
- P05: dense
- P06: dense
- P07: dense
- P08: dense
- P09: dense
- P10: dense
- P11: dense
- P12: dense
- P13: dense
- P14: dense
- P15: dense
- P16: dense
- P17: dense
- P18: breathing
- P19: dense
- P20: anchor
## forbidden
- Fabricated data and project outcomes
- Unverified industry statistics and legal claims
- Paid APIs
- SVG scripts, CSS, foreignObject
